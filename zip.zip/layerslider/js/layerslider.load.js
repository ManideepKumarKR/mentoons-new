 $(document).ready(function () {
	"use strict";

// Calling LayerSlider 
		
			$('#layerslider').layerSlider({
				sliderVersion: '6.0.0',
				skin: 'fullwidth',
				type: 'responsive', 
                globalBGSize:'cover',
			    hoverPrevNext:false,
				skinsPath: './layerslider/skins/'
			});
			
			

		
 });